const apiBaseUrl = "http://localhost:8083/api";
const token = localStorage.getItem("adminToken");

// Ensure Admin Token Exists
if (!token || !token.startsWith("eyJ")) {
    alert("Unauthorized! Please login as admin.");
    localStorage.removeItem("adminToken");
    window.location.href = "admin-login.html";
}

// Global headers for API calls
const headers = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${token}`
};

// Global variables
let allCategories = [];
let allPlans = [];
let currentCategoryId = null;
let currentPage = 1;
const plansPerPage = 5;

document.addEventListener('DOMContentLoaded', function () {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Fetch initial data
    fetchCategories();
    fetchRechargePlans();
    fetchUsers();
    fetchTransactions();
    fetchKYCRequests();
    loadStaticFeedback();
    loadStaticGraph();
    loadExpiringPlans();

    // Navigation
    document.querySelectorAll(".sidebar-nav a").forEach(link => {
        link.addEventListener("click", e => {
            e.preventDefault();
            const sectionId = link.getAttribute("href").substring(1);
            navigateTo(sectionId);
        });
    });
});


// Generic Fetch Function with Detailed Error Handling
async function fetchData(endpoint, method = "GET", body = null) {
    try {
        const options = { method, headers };
        if (body) options.body = JSON.stringify(body);
        const response = await fetch(`${apiBaseUrl}${endpoint}`, options);
        const text = await response.text();
        console.log(`Raw response from ${endpoint}:`, text);

        if (!response.ok) {
            if (response.status === 403) throw new Error("Access denied: Insufficient permissions.");
            if (response.status === 401) throw new Error("Unauthorized: Token expired or invalid.");
            if (response.status === 500) throw new Error(`Server error: ${text.substring(0, 200)}...`);
            throw new Error(`HTTP ${response.status}: ${text}`);
        }

        return text && method !== "PATCH" ? JSON.parse(text) : null;
    } catch (error) {
        console.error(`Error fetching ${endpoint}:`, error);
        showFeedback("Error: " + error.message, false);
        handleAuthError(error);
        return null;
    }
}

// Fetch Categories and Store Globally
async function fetchCategories() {
    allCategories = await fetchData("/categories") || [];
    console.log("Fetched categories:", allCategories);
    updateCategoriesUI(allCategories);
    fetchCategoriesForDropdown();
}

// Fetch Recharge Plans
async function fetchRechargePlans() {
    allPlans = await fetchData("/recharge-plans") || [];
    console.log("Fetched recharge plans:", allPlans);
    filterAndUpdatePlans();
}

// Fetch Categories for Dropdown
async function fetchCategoriesForDropdown() {
    const dropdowns = document.querySelectorAll("#planCategory, #editPlanCategory");
    dropdowns.forEach(dropdown => {
        dropdown.innerHTML = '<option value="" disabled selected>Select a category</option>';
        allCategories.forEach(category => {
            if (category.active) {
                const option = document.createElement("option");
                option.value = category.categoryId;
                option.textContent = category.categoryName;
                dropdown.appendChild(option);
            }
        });
    });
}

// Show Feedback Messages
function showFeedback(message, isSuccess = true) {
    const feedbackDiv = document.createElement("div");
    feedbackDiv.textContent = message;
    feedbackDiv.style.cssText = `
        position: fixed; top: 20px; right: 20px; padding: 15px; border-radius: 5px; z-index: 1000;
        background: ${isSuccess ? "#d4edda" : "#f8d7da"}; color: ${isSuccess ? "#155724" : "#721c24"};
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    `;
    document.body.appendChild(feedbackDiv);
    setTimeout(() => feedbackDiv.remove(), 3000);
}

// Handle Authentication Errors
function handleAuthError(error) {
    if (error.message.includes("Unauthorized") || error.message.includes("Access denied")) {
        showFeedback("Session expired. Redirecting to login...", false);
        setTimeout(() => {
            localStorage.removeItem("adminToken");
            window.location.href = "admin-login.html";
        }, 2000);
    }
}

// Add Recharge Plan
async function addRechargePlan() {
    const plan = {
        name: document.getElementById("planName").value.trim(),
        price: parseFloat(document.getElementById("planPrice").value) || 0,
        validity: document.getElementById("planValidity").value.trim(),
        dataLimit: document.getElementById("planData").value.trim(),
        category: { categoryId: parseInt(document.getElementById("planCategory").value) },
        active: true
    };

    if (!plan.name || !plan.category.categoryId) {
        showFeedback("Plan name and category are required!", false);
        return;
    }

    const addedPlan = await fetchData("/recharge-plans", "POST", plan);
    if (addedPlan) {
        showFeedback(`Recharge plan "${addedPlan.name}" added successfully!`, true);
        fetchRechargePlans();
        bootstrap.Modal.getInstance(document.getElementById("addPlanModal")).hide();
    }
}

// Update Recharge Plan
async function updateRechargePlan(planId) {
    const updatedPlan = {
        name: document.getElementById("editPlanName").value.trim(),
        price: parseFloat(document.getElementById("editPlanPrice").value) || 0,
        validity: document.getElementById("editPlanValidity").value.trim(),
        dataLimit: document.getElementById("editPlanData").value.trim(),
        category: { categoryId: parseInt(document.getElementById("editPlanCategory").value) },
        active: document.getElementById("editPlanActive").checked
    };

    if (!updatedPlan.name || !updatedPlan.category.categoryId) {
        showFeedback("Plan name and category are required!", false);
        return;
    }

    const result = await fetchData(`/recharge-plans/${planId}`, "PUT", updatedPlan);
    if (result) {
        showFeedback("Recharge plan updated successfully!", true);
        fetchRechargePlans();
        bootstrap.Modal.getInstance(document.getElementById("editPlanModal")).hide();
    }
}

// Toggle Recharge Plan Status
async function toggleRechargePlanStatus(planId, currentStatus) {
    const result = await fetchData(`/recharge-plans/${planId}/status?active=${!currentStatus}`, "PATCH");
    if (result === null) {
        showFeedback(`Plan ${currentStatus ? "deactivated" : "activated"} successfully!`, true);
        fetchRechargePlans();
    }
}

// Add Category
async function addCategory() {
    const category = {
        categoryName: document.getElementById("categoryName").value.trim(),
        active: true
    };
    if (!category.categoryName) {
        showFeedback("Category name is required!", false);
        return;
    }

    const addedCategory = await fetchData("/categories", "POST", category);
    if (addedCategory) {
        showFeedback(`Category "${addedCategory.categoryName}" added successfully!`, true);
        fetchCategories();
        bootstrap.Modal.getInstance(document.getElementById("addCategoryModal")).hide();
    }
}

// Update Category
async function updateCategory(categoryId) {
    const updatedCategory = {
        categoryName: document.getElementById("editCategoryName").value.trim(),
        active: document.getElementById("editCategoryActive").checked
    };
    if (!updatedCategory.categoryName) {
        showFeedback("Category name is required!", false);
        return;
    }

    const result = await fetchData(`/categories/${categoryId}`, "PUT", updatedCategory);
    if (result) {
        showFeedback("Category updated successfully!", true);
        fetchCategories();
        bootstrap.Modal.getInstance(document.getElementById("editCategoryModal")).hide();
    }
}

// Toggle Category Status
async function toggleCategoryStatus(categoryId, currentStatus) {
    const result = await fetchData(`/categories/${categoryId}/status?active=${!currentStatus}`, "PATCH");
    if (result === null) {
        showFeedback(`Category ${currentStatus ? "deactivated" : "activated"} successfully!`, true);
        fetchCategories();
    }
}

// Filter and Update Recharge Plans UI with Pagination
function filterAndUpdatePlans() {
    let filteredPlans = currentCategoryId 
        ? allPlans.filter(plan => plan.category?.categoryId === currentCategoryId)
        : allPlans;
    const start = (currentPage - 1) * plansPerPage;
    const end = start + plansPerPage;
    const paginatedPlans = filteredPlans.slice(start, end);

    const tbody = document.querySelector("#rechargePlansTable tbody");
    if (tbody) {
        tbody.innerHTML = "";
        paginatedPlans.forEach(plan => {
            const category = allCategories.find(cat => cat.categoryId === plan.category?.categoryId);
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${plan.name}</td>
                <td>₹${plan.price.toFixed(2)}</td>
                <td>${plan.validity}</td>
                <td>${plan.dataLimit}</td>
                <td>${category ? category.categoryName : "Unknown"}</td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="editRechargePlan('${plan.planId}')">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-sm ${plan.active ? 'btn-danger' : 'btn-success'}" 
                            onclick="toggleRechargePlanStatus('${plan.planId}', ${plan.active})">
                        <i class="fas ${plan.active ? 'fa-ban' : 'fa-check'}"></i> ${plan.active ? "Deactivate" : "Activate"}
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
        updatePagination(filteredPlans.length);
    }
}

// Update Pagination Controls
function updatePagination(totalPlans) {
    const pagination = document.getElementById("pagination") || document.createElement("div");
    pagination.id = "pagination";
    pagination.className = "mt-3";
    const totalPages = Math.ceil(totalPlans / plansPerPage);
    pagination.innerHTML = `
        <button class="btn btn-secondary me-2" ${currentPage === 1 ? 'disabled' : ''} onclick="currentPage--; filterAndUpdatePlans()">Previous</button>
        <span class="mx-2">Page ${currentPage} of ${totalPages}</span>
        <button class="btn btn-secondary" ${currentPage === totalPages ? 'disabled' : ''} onclick="currentPage++; filterAndUpdatePlans()">Next</button>
    `;
    const plansSection = document.getElementById("recharge-plans");
    if (!pagination.parentElement) plansSection.appendChild(pagination);
}

// Update Categories UI
function updateCategoriesUI(categories) {
    const tbody = document.querySelector("#categoriesTable tbody");
    if (tbody) {
        tbody.innerHTML = "";
        categories.forEach(category => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td><a href="#" onclick="filterPlansByCategory(${category.categoryId}); return false;">${category.category}</a></td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="editCategory('${category.categoryId}')">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-sm ${category.active ? 'btn-danger' : 'btn-success'}" 
                            onclick="toggleCategoryStatus('${category.categoryId}', ${category.active})">
                        <i class="fas ${category.active ? 'fa-ban' : 'fa-check'}"></i> ${category.active ? "Deactivate" : "Activate"}
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }
}

// Filter Plans by Category
function filterPlansByCategory(categoryId) {
    currentCategoryId = categoryId;
    currentPage = 1;
    filterAndUpdatePlans();
}

// Edit Recharge Plan
function editRechargePlan(planId) {
    const plan = allPlans.find(p => p.planId === planId);
    if (plan) {
        document.getElementById("editPlanId").value = plan.planId;
        document.getElementById("editPlanName").value = plan.name;
        document.getElementById("editPlanPrice").value = plan.price;
        document.getElementById("editPlanValidity").value = plan.validity;
        document.getElementById("editPlanData").value = plan.dataLimit;
        document.getElementById("editPlanCategory").value = plan.category?.categoryId || "";
        document.getElementById("editPlanActive").checked = plan.active;
        new bootstrap.Modal(document.getElementById("editPlanModal")).show();
    }
}

// Edit Category
function editCategory(categoryId) {
    const category = allCategories.find(c => c.categoryId === categoryId);
    if (category) {
        document.getElementById("editCategoryId").value = category.categoryId;
        document.getElementById("editCategoryName").value = category.categoryName;
        document.getElementById("editCategoryActive").checked = category.active;
        new bootstrap.Modal(document.getElementById("editCategoryModal")).show();
    }
}

// Logout Admin
function adminLogout() {
    localStorage.removeItem("adminToken");
    showFeedback("Logged out successfully!", true);
    setTimeout(() => window.location.href = "admin-login.html", 1000);
}

// Fetch Users
async function fetchUsers() {
    const users = await fetchData("/users") || [];
    updateUsersUI(users);
}

// Update Users UI
function updateUsersUI(users) {
    const tbody = document.querySelector("#usersTable tbody");
    if (tbody) {
        tbody.innerHTML = "";
        users.forEach(user => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${user.userId || "N/A"}</td>
                <td>${user.username || "N/A"}</td>
                <td>${user.email || "N/A"}</td>
                <td>${user.mobile || "N/A"}</td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="viewUserTransactions('${user.userId}')">
                        <i class="fas fa-eye"></i> View Transactions
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }
}

// View User Transactions
async function viewUserTransactions(userId) {
    const transactions = await fetchData(`/users/${userId}/transactions`) || [];
    updateTransactionsUI(transactions);
}

// Update Transactions UI
function updateTransactionsUI(transactions) {
    const tbody = document.querySelector("#transactionsTable tbody");
    if (tbody) {
        tbody.innerHTML = "";
        transactions.forEach(transaction => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${transaction.transactionId || "N/A"}</td>
                <td>${transaction.planName || "N/A"}</td>
                <td>₹${transaction.amount || "N/A"}</td>
                <td>${transaction.date || "N/A"}</td>
                <td>${transaction.status || "N/A"}</td>
            `;
            tbody.appendChild(row);
        });
    }
    navigateTo("transaction-history");
}

// Fetch KYC Requests
async function fetchKYCRequests() {
    const kycRequests = await fetchData("/kyc-requests") || [];
    updateKYCRequestsUI(kycRequests);
}

// Update KYC Requests UI
function updateKYCRequestsUI(kycRequests) {
    const tbody = document.querySelector("#kycRequestsTable tbody");
    if (tbody) {
        tbody.innerHTML = "";
        kycRequests.forEach(request => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${request.requestId || "N/A"}</td>
                <td>${request.userId || "N/A"}</td>
                <td>${request.status || "N/A"}</td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="viewKYCRequest('${request.requestId}')">
                        <i class="fas fa-eye"></i> View
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }
}

// View KYC Request
async function viewKYCRequest(requestId) {
    const request = await fetchData(`/kyc-requests/${requestId}`) || {};
    updateKYCRequestUI(request);
}

// Update KYC Request UI
function updateKYCRequestUI(request) {
    const modalBody = document.getElementById("kycRequestModalBody");
    if (modalBody) {
        modalBody.innerHTML = `
            <p><strong>Request ID:</strong> ${request.requestId || "N/A"}</p>
            <p><strong>User ID:</strong> ${request.userId || "N/A"}</p>
            <p><strong>Status:</strong> ${request.status || "N/A"}</p>
            <p><strong>Details:</strong> ${request.details || "No details provided"}</p>
        `;
        new bootstrap.Modal(document.getElementById("kycRequestModal")).show();
    }
}

// Load Static Feedback
function loadStaticFeedback() {
    const feedback = [
        { id: 1, message: "Great service!", rating: 5 },
        { id: 2, message: "Could be better.", rating: 3 }
    ];
    updateFeedbackUI(feedback);
}

// Update Feedback UI
function updateFeedbackUI(feedback) {
    const tbody = document.querySelector("#feedbackTable tbody");
    if (tbody) {
        tbody.innerHTML = "";
        feedback.forEach(item => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${item.id}</td>
                <td>${item.message}</td>
                <td>${item.rating}</td>
            `;
            tbody.appendChild(row);
        });
    }
}

// Load Static Graph
function loadStaticGraph() {
    const ctx = document.getElementById("analyticsChart")?.getContext("2d");
    if (ctx) {
        new Chart(ctx, {
            type: "bar",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [{
                    label: "Recharges",
                    data: [65, 59, 80, 81, 56, 55, 40],
                    backgroundColor: "rgba(75, 192, 192, 0.2)",
                    borderColor: "rgba(75, 192, 192, 1)",
                    borderWidth: 1
                }]
            },
            options: {
                scales: { y: { beginAtZero: true } }
            }
        });
    }
}

// Navigation for Admin Dashboard
function navigateTo(sectionId) {
    document.querySelectorAll(".admin-section").forEach(section => {
        section.classList.remove("active");
    });
    document.querySelectorAll(".sidebar-nav a").forEach(link => {
        link.classList.remove("active");
    });
    const targetSection = document.getElementById(sectionId);
    if (targetSection) targetSection.classList.add("active");
    const targetLink = document.querySelector(`.sidebar-nav a[href="#${sectionId}"]`);
    if (targetLink) targetLink.classList.add("active");
}

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    sidebar.classList.toggle("collapsed");
}

// Event Listeners
document.getElementById("logoutBtn")?.addEventListener("click", adminLogout);
document.getElementById("addRechargePlanForm")?.addEventListener("submit", e => {
    e.preventDefault();
    addRechargePlan();
});
document.getElementById("addCategoryForm")?.addEventListener("submit", e => {
    e.preventDefault();
    addCategory();
});
document.getElementById("saveEditedPlan")?.addEventListener("click", () => {
    const planId = document.getElementById("editPlanId").value;
    updateRechargePlan(planId);
});
document.getElementById("saveEditedCategory")?.addEventListener("click", () => {
    const categoryId = document.getElementById("editCategoryId").value;
    updateCategory(categoryId);
});

// --- New Functionalities ---

// 1. Admin Panel & Multi-Provider Management

// Monitor Failed Payments (Placeholder)
async function monitorFailedPayments() {
    const failedPayments = await fetchData("/transactions/failed") || [];
    // Assuming an endpoint exists; update UI or log for now
    console.log("Failed payments:", failedPayments);
    showFeedback("Fetched failed payments. Check console for details.", true);
}

// Process Refund (Placeholder)
async function processRefund(transactionId) {
    const result = await fetchData(`/transactions/${transactionId}/refund`, "POST");
    if (result) {
        showFeedback("Refund processed successfully!", true);
        fetchTransactions();
    }
}

// Send Notification (Placeholder)
async function sendNotification(message, userIds) {
    const notification = { message, userIds };
    const result = await fetchData("/notifications", "POST", notification);
    if (result) showFeedback("Notification sent successfully!", true);
}

// Manage Customer Support Requests (Placeholder)
async function fetchSupportRequests() {
    const requests = await fetchData("/support-requests") || [];
    console.log("Support requests:", requests);
    showFeedback("Fetched support requests. Check console for details.", true);
}

// Analyse Feedback Trends (Simple Average Rating)
function analyseFeedbackTrends(feedback) {
    const avgRating = feedback.reduce((sum, item) => sum + item.rating, 0) / feedback.length;
    showFeedback(`Average feedback rating: ${avgRating.toFixed(1)}`, true);
}

// 2. Viewing Subscribers with Expiring Plans
async function loadExpiringPlans() {
    // Placeholder: Replace with API call to "/users/expiring-plans?days=3"
    const expiringPlans = [
        { name: "Rahul Singh", mobile: "9876543210", plan: "Monthly Unlimited", expiry: "2025-03-28", daysLeft: 2, lastAmount: 299 },
        { name: "Priya Sharma", mobile: "8765432109", plan: "Data Pack 2GB/day", expiry: "2025-03-27", daysLeft: 1, lastAmount: 199 },
        { name: "Amit Kumar", mobile: "7654321098", plan: "Quarterly Premium", expiry: "2025-03-29", daysLeft: 3, lastAmount: 599 }
    ];

    const tbody = document.querySelector("#expiringPlansTable tbody");
    if (!tbody) {
        const section = document.getElementById("users");
        section.innerHTML += `
            <h3>Expiring Plans (Next 3 Days)</h3>
            <table id="expiringPlansTable" class="table table-striped">
                <thead><tr><th>Name</th><th>Mobile</th><th>Plan</th><th>Expiry</th><th>Days Left</th><th>Last Amount</th><th>Action</th></tr></thead>
                <tbody></tbody>
            </table>
        `;
    }

    const expiringTbody = document.querySelector("#expiringPlansTable tbody");
    expiringTbody.innerHTML = "";
    expiringPlans.forEach(plan => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${plan.name}</td>
            <td>${plan.mobile}</td>
            <td>${plan.plan}</td>
            <td>${plan.expiry}</td>
            <td><span class="badge ${plan.daysLeft <= 1 ? 'bg-danger' : 'bg-warning'}">${plan.daysLeft} days</span></td>
            <td>₹${plan.lastAmount}</td>
            <td><button class="btn btn-info btn-sm" onclick="sendReminder('${plan.mobile}')">Remind</button></td>
        `;
        expiringTbody.appendChild(row);
    });
}

// Send Reminder (Placeholder)
function sendReminder(mobile) {
    sendNotification(`Your plan is expiring soon. Recharge now!`, [mobile]);
}

// 3. Viewing & Filtering Recharge History
async function fetchTransactions() {
    const transactions = await fetchData("/transactions") || [];
    updateTransactionsUI(transactions);
}

// Filter Transactions
function filterTransactions() {
    const date = document.getElementById("filterDate")?.value;
    const amount = document.getElementById("filterAmount")?.value;
    const paymentMethod = document.getElementById("filterPaymentMethod")?.value;
    const status = document.getElementById("filterStatus")?.value;

    fetchData("/transactions").then(transactions => {
        let filtered = transactions || [];
        if (date) filtered = filtered.filter(t => t.date.includes(date));
        if (amount) filtered = filtered.filter(t => t.amount == amount);
        if (paymentMethod) filtered = filtered.filter(t => t.paymentMethod === paymentMethod);
        if (status) filtered = filtered.filter(t => t.status === status);
        updateTransactionsUI(filtered);
    });
}

// Add filter UI dynamically if not present
if (!document.getElementById("transactionFilters")) {
    const section = document.getElementById("transaction-history");
    section.insertAdjacentHTML("afterbegin", `
        <div id="transactionFilters" class="mb-3">
            <input type="date" id="filterDate" class="form-control d-inline-block w-auto" onchange="filterTransactions()">
            <input type="number" id="filterAmount" placeholder="Amount" class="form-control d-inline-block w-auto" onchange="filterTransactions()">
            <select id="filterPaymentMethod" class="form-control d-inline-block w-auto" onchange="filterTransactions()">
                <option value="">Payment Method</option>
                <option value="UPI">UPI</option>
                <option value="Card">Card</option>
                <option value="Netbanking">Netbanking</option>
            </select>
            <select id="filterStatus" class="form-control d-inline-block w-auto" onchange="filterTransactions()">
                <option value="">Status</option>
                <option value="Success">Success</option>
                <option value="Failed">Failed</option>
                <option value="Pending">Pending</option>
            </select>
        </div>
    `);
}